package com.apps.jivory.collegeapp.models;

public interface CollegeScorecardResponse {
    void processFinish(CollegeQuery collegeQuery);
}

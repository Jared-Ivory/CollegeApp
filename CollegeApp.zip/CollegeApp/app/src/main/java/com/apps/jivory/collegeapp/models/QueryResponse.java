package com.apps.jivory.collegeapp.models;

public interface QueryResponse {
    void foobar(CollegeQuery collegeQuery);
}

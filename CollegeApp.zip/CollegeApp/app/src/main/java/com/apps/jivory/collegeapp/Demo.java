package com.apps.jivory.collegeapp;

import android.os.AsyncTask;

import com.apps.jivory.collegeapp.models.College;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Demo {
    private static String scorecard_api = "http://api.data.gov/ed/collegescorecard/v1/schools";

    public Demo(){
    }
}
